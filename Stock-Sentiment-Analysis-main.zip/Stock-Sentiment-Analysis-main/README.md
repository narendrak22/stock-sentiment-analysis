# Stock-Sentiment-Analysis
a simple ML project based on data collected from ML kaggle , i have used NLP and then random forest regressor to predict whethter the DJAI will go up , down or stays the same.
